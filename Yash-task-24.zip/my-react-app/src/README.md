Hello World React App

About

This is a simple React application that displays Hello World on the screen.

Technologies Used

React
JavaScript
JSX

Features

Displays Hello World heading
Uses a functional component
Exports the App component

How to Run

Create a React project
Add the given code in App jsx
Open the terminal in the project folder
Run npm install
Run npm run dev
Open the local URL in your browser

Author

Yash